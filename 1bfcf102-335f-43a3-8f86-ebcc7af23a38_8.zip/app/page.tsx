
'use client';

import Link from 'next/link';

export default function Home() {
  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section 
        className="relative min-h-screen flex items-center justify-center bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.4), rgba(0, 0, 0, 0.4)), url('https://readdy.ai/api/search-image?query=Professional%20business%20success%20concept%20with%20confident%20entrepreneur%20in%20modern%20office%2C%20gold%20and%20blue%20color%20scheme%2C%20minimalist%20clean%20background%2C%20professional%20lighting%2C%20success%20motivation%20theme%2C%20modern%20business%20atmosphere&width=1920&height=1080&seq=hero-ebook&orientation=landscape')`
        }}
      >
        <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-6 leading-tight">
              Como fazer o cliente dizer<br />
              <span className="text-yellow-400">"QUERO JÁ"</span>
            </h1>
            <p className="text-xl md:text-2xl text-gray-200 mb-8 max-w-3xl mx-auto">
              Descubra os segredos psicológicos que fazem seus clientes comprarem na hora. 
              O método comprovado usado por vendedores que faturam 6 dígitos por mês.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-8">
              <a 
                href="https://mozpayment.co.mz/pagaemento?check=1737318073763x319215396411932700" 
                target="_blank" 
                rel="noopener noreferrer"
                className="inline-block bg-yellow-500 hover:bg-yellow-600 text-black font-bold text-lg px-12 py-4 rounded-full transition-all transform hover:scale-105 cursor-pointer whitespace-nowrap"
              >
                COMPRAR AGORA - 120 MT
              </a>
              <div className="text-white text-center">
                <p className="text-sm line-through opacity-75">De 360 MT</p>
                <p className="text-yellow-400 font-bold">67% de desconto!</p>
              </div>
            </div>
            <div className="flex items-center justify-center gap-4 text-white text-sm">
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 flex items-center justify-center">
                  <i className="ri-shield-check-line"></i>
                </div>
                <span>Garantia 30 dias</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 flex items-center justify-center">
                  <i className="ri-download-line"></i>
                </div>
                <span>Download imediato</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 flex items-center justify-center">
                  <i className="ri-secure-payment-line"></i>
                </div>
                <span>Pagamento seguro</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Problema Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-6">
              Você já passou por isso?
            </h2>
            <div className="grid md:grid-cols-3 gap-8">
              <div className="bg-white p-8 rounded-xl shadow-lg">
                <div className="w-16 h-16 mx-auto mb-4 bg-red-100 rounded-full flex items-center justify-center">
                  <i className="ri-emotion-sad-line text-2xl text-red-500"></i>
                </div>
                <h3 className="text-xl font-semibold mb-4 text-gray-900">Cliente interessado...</h3>
                <p className="text-gray-600">Mas na hora H ele some, não responde mais e você fica sem entender o que aconteceu.</p>
              </div>
              <div className="bg-white p-8 rounded-xl shadow-lg">
                <div className="w-16 h-16 mx-auto mb-4 bg-red-100 rounded-full flex items-center justify-center">
                  <i className="ri-time-line text-2xl text-red-500"></i>
                </div>
                <h3 className="text-xl font-semibold mb-4 text-gray-900">Enrolação sem fim</h3>
                <p className="text-gray-600">"Vou pensar", "Preciso conversar com minha esposa", "Vou ver se tenho dinheiro"...</p>
              </div>
              <div className="bg-white p-8 rounded-xl shadow-lg">
                <div className="w-16 h-16 mx-auto mb-4 bg-red-100 rounded-full flex items-center justify-center">
                  <i className="ri-money-dollar-circle-line text-2xl text-red-500"></i>
                </div>
                <h3 className="text-xl font-semibold mb-4 text-gray-900">Vendas perdidas</h3>
                <p className="text-gray-600">Você sabe que seu produto resolve o problema, mas não consegue fazer o cliente DECIDIR.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Solução Section */}
      <section className="py-20 bg-blue-900 text-white">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-bold mb-6">
                A solução que você precisa está aqui
              </h2>
              <p className="text-xl mb-8 text-blue-100">
                Depois de 15 anos vendendo e estudando comportamento do consumidor, 
                descobri os gatilhos mentais que fazem qualquer pessoa dizer "QUERO JÁ" 
                na hora da venda.
              </p>
              <ul className="space-y-4 mb-8">
                <li className="flex items-start gap-3">
                  <div className="w-6 h-6 flex items-center justify-center">
                    <i className="ri-check-line text-yellow-400 text-xl"></i>
                  </div>
                  <span className="text-blue-100">7 gatilhos psicológicos comprovados cientificamente</span>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-6 h-6 flex items-center justify-center">
                    <i className="ri-check-line text-yellow-400 text-xl"></i>
                  </div>
                  <span className="text-blue-100">Scripts prontos para usar em qualquer nicho</span>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-6 h-6 flex items-center justify-center">
                    <i className="ri-check-line text-yellow-400 text-xl"></i>
                  </div>
                  <span className="text-blue-100">Método testado com mais de 10.000 vendas</span>
                </li>
              </ul>
            </div>
            <div className="text-center">
              <div className="relative inline-block">
                <div className="absolute inset-0 bg-gradient-to-br from-yellow-400 via-orange-500 to-red-500 rounded-2xl blur-xl opacity-30 scale-110"></div>
                <div className="relative bg-gradient-to-br from-gray-800 to-gray-900 p-6 rounded-2xl shadow-2xl">
                  <div className="bg-white p-3 rounded-xl shadow-inner">
                    <img 
                      src="https://static.readdy.ai/image/70e8491c186e5c107fcbe30597ad56c8/d89588e62c2fb7d1b70dc637f540b646.png"
                      alt="Ebook Como fazer o cliente dizer QUERO JÁ"
                      className="mx-auto rounded-lg shadow-lg object-top max-w-sm w-full"
                    />
                  </div>
                  <div className="mt-4 text-center">
                    <div className="flex justify-center space-x-1 mb-2">
                      {[...Array(5)].map((_, i) => (
                        <i key={i} className="ri-star-fill text-yellow-400 text-lg"></i>
                      ))}
                    </div>
                    <p className="text-yellow-400 text-sm font-semibold">Mais de 5.000 vendas!</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* O que você vai aprender */}
      <section className="py-20 bg-white">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-6">
              O que você vai aprender
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Um método completo, passo a passo, para transformar qualquer pessoa interessada em um cliente que compra NA HORA.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-8 rounded-xl">
              <div className="w-12 h-12 bg-blue-500 rounded-lg flex items-center justify-center mb-4">
                <i className="ri-brain-line text-white text-xl"></i>
              </div>
              <h3 className="text-xl font-semibold mb-4 text-gray-900">Psicologia da Urgência</h3>
              <p className="text-gray-600">Como criar uma necessidade imediata no cliente sem parecer desesperado.</p>
            </div>
            <div className="bg-gradient-to-br from-green-50 to-green-100 p-8 rounded-xl">
              <div className="w-12 h-12 bg-green-500 rounded-lg flex items-center justify-center mb-4">
                <i className="ri-target-line text-white text-xl"></i>
              </div>
              <h3 className="text-xl font-semibold mb-4 text-gray-900">Gatilho da Escassez</h3>
              <p className="text-gray-600">A técnica para fazer o cliente sentir que pode perder a oportunidade para sempre.</p>
            </div>
            <div className="bg-gradient-to-br from-purple-50 to-purple-100 p-8 rounded-xl">
              <div className="w-12 h-12 bg-purple-500 rounded-lg flex items-center justify-center mb-4">
                <i className="ri-group-line text-white text-xl"></i>
              </div>
              <h3 className="text-xl font-semibold mb-4 text-gray-900">Prova Social</h3>
              <p className="text-gray-600">Como usar o comportamento de manada a seu favor nas vendas.</p>
            </div>
            <div className="bg-gradient-to-br from-yellow-50 to-yellow-100 p-8 rounded-xl">
              <div className="w-12 h-12 bg-yellow-500 rounded-lg flex items-center justify-center mb-4">
                <i className="ri-money-cny-circle-line text-white text-xl"></i>
              </div>
              <h3 className="text-xl font-semibold mb-4 text-gray-900">Ancoragem de Preço</h3>
              <p className="text-gray-600">O segredo para fazer qualquer preço parecer barato e justo.</p>
            </div>
            <div className="bg-gradient-to-br from-red-50 to-red-100 p-8 rounded-xl">
              <div className="w-12 h-12 bg-red-500 rounded-lg flex items-center justify-center mb-4">
                <i className="ri-heart-pulse-line text-white text-xl"></i>
              </div>
              <h3 className="text-xl font-semibold mb-4 text-gray-900">Conexão Emocional</h3>
              <p className="text-gray-600">Como tocar nos pontos de dor do cliente e criar conexão instantânea.</p>
            </div>
            <div className="bg-gradient-to-br from-indigo-50 to-indigo-100 p-8 rounded-xl">
              <div className="w-12 h-12 bg-indigo-500 rounded-lg flex items-center justify-center mb-4">
                <i className="ri-rocket-line text-white text-xl"></i>
              </div>
              <h3 className="text-xl font-semibold mb-4 text-gray-900">Scripts de Fechamento</h3>
              <p className="text-gray-600">15 frases poderosas que fazem o cliente dizer "SIM" imediatamente.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Depoimentos */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-6">
              Veja o que nossos clientes estão dizendo
            </h2>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-xl shadow-lg">
              <div className="flex items-center mb-4">
                <img 
                  src="https://readdy.ai/api/search-image?query=Professional%20Brazilian%20businessman%20in%20his%2040s%2C%20confident%20smile%2C%20modern%20office%20background%2C%20professional%20headshot%20style%2C%20business%20success%20theme&width=60&height=60&seq=testimonial-1&orientation=squarish"
                  alt="Carlos Silva"
                  className="w-12 h-12 rounded-full object-top mr-4"
                />
                <div>
                  <h4 className="font-semibold text-gray-900">Carlos Silva</h4>
                  <p className="text-gray-600 text-sm">Consultor de Negócios</p>
                </div>
              </div>
              <div className="flex mb-4">
                {[...Array(5)].map((_, i) => (
                  <i key={i} className="ri-star-fill text-yellow-400"></i>
                ))}
              </div>
              <p className="text-gray-600">
                "Aumentei minhas vendas em 340% em apenas 2 meses aplicando as técnicas do ebook. 
                Agora meus clientes literalmente imploram para comprar!"
              </p>
            </div>
            <div className="bg-white p-8 rounded-xl shadow-lg">
              <div className="flex items-center mb-4">
                <img 
                  src="https://readdy.ai/api/search-image?query=Professional%20Brazilian%20businesswoman%20in%20her%2030s%2C%20confident%20expression%2C%20modern%20corporate%20setting%2C%20professional%20headshot%20photography%2C%20success%20theme&width=60&height=60&seq=testimonial-2&orientation=squarish"
                  alt="Maria Santos"
                  className="w-12 h-12 rounded-full object-top mr-4"
                />
                <div>
                  <h4 className="font-semibold text-gray-900">Maria Santos</h4>
                  <p className="text-gray-600 text-sm">Empreendedora Digital</p>
                </div>
              </div>
              <div className="flex mb-4">
                {[...Array(5)].map((_, i) => (
                  <i key={i} className="ri-star-fill text-yellow-400"></i>
                ))}
              </div>
              <p className="text-gray-600">
                "Método revolucionário! Consegui 150.000 MT em vendas no primeiro mês usando os gatilhos mentais. 
                Simplesmente funciona!"
              </p>
            </div>
            <div className="bg-white p-8 rounded-xl shadow-lg">
              <div className="flex items-center mb-4">
                <img 
                  src="https://readdy.ai/api/search-image?query=Young%20Brazilian%20entrepreneur%20male%2C%20modern%20casual%20business%20attire%2C%20startup%20office%20environment%2C%20confident%20professional%20look%2C%20innovation%20theme&width=60&height=60&seq=testimonial-3&orientation=squarish"
                  alt="João Oliveira"
                  className="w-12 h-12 rounded-full object-top mr-4"
                />
                <div>
                  <h4 className="font-semibold text-gray-900">João Oliveira</h4>
                  <p className="text-gray-600 text-sm">Coach de Vendas</p>
                </div>
              </div>
              <div className="flex mb-4">
                {[...Array(5)].map((_, i) => (
                  <i key={i} className="ri-star-fill text-yellow-400"></i>
                ))}
              </div>
              <p className="text-gray-600">
                "Era cético, mas decidi testar. Resultado: taxa de conversão subiu de 15% para 68%. 
                Melhor investimento que já fiz!"
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Garantia */}
      <section className="py-20 bg-green-600 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="w-20 h-20 mx-auto mb-6 bg-green-500 rounded-full flex items-center justify-center">
            <i className="ri-shield-check-line text-3xl"></i>
          </div>
          <h2 className="text-4xl font-bold mb-6">
            Garantia Incondicional de 30 Dias
          </h2>
          <p className="text-xl mb-8 text-green-100">
            Se você não aumentar suas vendas em pelo menos 200% nos próximos 30 dias, 
            eu devolvo 100% do seu dinheiro. Sem perguntas, sem burocracia.
          </p>
          <p className="text-lg text-green-200">
            Você não tem nada a perder e muito dinheiro para ganhar!
          </p>
        </div>
      </section>

      {/* Urgência */}
      <section className="py-20 bg-red-600 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold mb-6">
            ⚠️ ATENÇÃO: Oferta por tempo limitado!
          </h2>
          <p className="text-2xl mb-8">
            Apenas <span className="bg-yellow-400 text-black px-4 py-1 rounded font-bold">47 cópias</span> restantes
          </p>
          <div className="bg-black/30 p-8 rounded-xl mb-8">
            <h3 className="text-3xl font-bold mb-4">Esta oferta expira em:</h3>
            <div className="flex justify-center gap-4 text-center">
              <div className="bg-white text-black p-4 rounded-lg">
                <div className="text-3xl font-bold">02</div>
                <div className="text-sm">Dias</div>
              </div>
              <div className="bg-white text-black p-4 rounded-lg">
                <div className="text-3xl font-bold">14</div>
                <div className="text-sm">Horas</div>
              </div>
              <div className="bg-white text-black p-4 rounded-lg">
                <div className="text-3xl font-bold">37</div>
                <div className="text-sm">Min</div>
              </div>
              <div className="bg-white text-black p-4 rounded-lg">
                <div className="text-3xl font-bold">22</div>
                <div className="text-sm">Seg</div>
              </div>
            </div>
          </div>
          <p className="text-xl text-red-200">
            Depois disso, o preço volta para 360 MT
          </p>
        </div>
      </section>

      {/* CTA Final */}
      <section className="py-20 bg-yellow-400">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl md:text-5xl font-bold text-black mb-6">
            Pare de perder vendas agora mesmo!
          </h2>
          <p className="text-xl text-black mb-8 max-w-2xl mx-auto">
            Enquanto você hesita, seus concorrentes estão usando essas técnicas para roubar seus clientes. 
            Não deixe isso acontecer!
          </p>
          <div className="mb-8">
            <div className="text-black text-2xl mb-4">
              <span className="line-through opacity-60">360 MT</span>
            </div>
            <div className="text-5xl font-bold text-black mb-4">
              120 MT
            </div>
            <div className="text-lg text-black font-semibold">
              67% de desconto - Apenas hoje!
            </div>
          </div>
          <a 
            href="https://mozpayment.co.mz/pagaemento?check=1737318073763x319215396411932700" 
            target="_blank" 
            rel="noopener noreferrer"
            className="inline-block bg-black hover:bg-gray-800 text-white font-bold text-2xl px-16 py-6 rounded-full transition-all transform hover:scale-105 cursor-pointer whitespace-nowrap mb-6"
          >
            QUERO COMEÇAR A VENDER MAIS HOJE! 🚀
          </a>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center text-black text-sm">
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 flex items-center justify-center">
                <i className="ri-shield-check-line"></i>
              </div>
              <span>Garantia 30 dias</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 flex items-center justify-center">
                <i className="ri-download-line"></i>
              </div>
              <span>Acesso imediato</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 flex items-center justify-center">
                <i className="ri-secure-payment-line"></i>
              </div>
              <span>Pagamento 100% seguro</span>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h3 className="text-2xl font-bold mb-4">Como fazer o cliente dizer "QUERO JÁ"</h3>
            <p className="text-gray-400 mb-8">
              O método comprovado para aumentar suas vendas imediatamente
            </p>
            <div className="flex justify-center space-x-6 mb-8">
              <a href="#" className="text-gray-400 hover:text-white cursor-pointer">
                <div className="w-6 h-6 flex items-center justify-center">
                  <i className="ri-facebook-fill text-xl"></i>
                </div>
              </a>
              <a href="#" className="text-gray-400 hover:text-white cursor-pointer">
                <div className="w-6 h-6 flex items-center justify-center">
                  <i className="ri-instagram-line text-xl"></i>
                </div>
              </a>
              <a href="#" className="text-gray-400 hover:text-white cursor-pointer">
                <div className="w-6 h-6 flex items-center justify-center">
                  <i className="ri-youtube-line text-xl"></i>
                </div>
              </a>
              <a href="#" className="text-gray-400 hover:text-white cursor-pointer">
                <div className="w-6 h-6 flex items-center justify-center">
                  <i className="ri-linkedin-fill text-xl"></i>
                </div>
              </a>
            </div>
            <div className="border-t border-gray-800 pt-8">
              <p className="text-gray-400 text-sm">
                2024 Como fazer o cliente dizer "QUERO JÁ". Todos os direitos reservados.
              </p>
              <p className="text-gray-400 text-sm mt-2">
                Termos de Uso | Política de Privacidade | Suporte
              </p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
